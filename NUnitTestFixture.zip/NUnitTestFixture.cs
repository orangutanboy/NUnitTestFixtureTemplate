﻿using NUnit.Framework;
using Rhino.Mocks;

namespace $rootnamespace$
{
    [TestFixture]
    public class $itemname$
    {
        [Test]
        public void FailingTest()
        {
            Assert.Fail();
        }
    }
}
