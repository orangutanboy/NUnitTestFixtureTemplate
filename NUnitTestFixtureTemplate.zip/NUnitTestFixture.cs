﻿using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;

namespace $rootnamespace$
{
	/// <summary>
	/// The text fixture for <see cref="$itemname$" />.
	/// </summary>
    [TestFixture]
    public class $itemname$
    {
		/// <summary>
		/// Test for <see cref="$itemname$" />.
		/// </summary>
        [Test]
        public void Test()
        {
            
        }
    }
}

